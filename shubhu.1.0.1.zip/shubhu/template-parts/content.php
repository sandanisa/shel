<?php
/**
* Template part for displaying posts
*
* @link https://developer.wordpress.org/themes/basics/template-hierarchy/
*
* @package Shubhu
*/
global $shubhu_theme_options;
$show_content_from = esc_attr($shubhu_theme_options['shubhu-content-show-from']);
$masonry = esc_attr($shubhu_theme_options['shubhu-column-blog-page']);
$image_location = esc_attr($shubhu_theme_options['shubhu-blog-image-layout']);
$social_share = absint($shubhu_theme_options['shubhu-show-hide-share']);
$date = absint($shubhu_theme_options['shubhu-show-hide-date']);
$category = absint($shubhu_theme_options['shubhu-show-hide-category']);
$author = absint($shubhu_theme_options['shubhu-show-hide-author']);
#
?>
<article id="post-<?php the_ID(); ?>" <?php post_class($masonry); ?>>
    <div class="blog-item <?php echo esc_attr($image_location); ?>" data-wow-duration="1s">
        <?php if(has_post_thumbnail()) { ?>
        <div class="blog-img">
            <?php shubhu_post_thumbnail(); ?>
            <div class="blog-img-content">
                <div class="display-table-cell">
                    <a class="blog-link" href="<?php the_permalink(); ?>">
                        <i class="fa fa-link"></i>
                    </a>
                </div>
            </div>
        </div>
        <?php } ?>
        <div class="full-blog-content">
            <div class="blog-meta">
                <?php
                if ('post' === get_post_type()) :
                    ?>
                    <ul class="post-meta list-inline ">
                        <li class="list-inline-item">
                            <?php
                                if($category == 1 ){
                                    $categories = get_the_category();
                                        if ( ! empty( $categories ) ) {
                                        echo '<a class="category" href="'.esc_url( get_category_link( $categories[0]->term_id ) ).'">'.esc_html( $categories[0]->name ).'</a>';
                                    }
                                }
                            ?>
                        </li>
                        <li class="list-inline-item">
                            <?php    
                                if($date == 1 ){
                                    shubhu_posted_on();
                                }
                            ?>
                        </li>
                    </ul>
                <?php endif; ?>
                <?php
                if (is_singular()) :
                the_title('<h1 class="post-title entry-title">', '</h1>');
                else :
                the_title('<h3 class="blog-title"><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h3>');
                ?>
                <?php endif; ?>
            </div>
            <div class="blog-desc">
                <?php
                if (is_singular()) {
                    the_content();
                } else {
                    if ($show_content_from == 'excerpt') {
                        the_excerpt();
                    }elseif($show_content_from == 'content') {
                        the_content();
                    }else {
                        empty('');
                    }
                }
                wp_link_pages(array(
                'before' => '<div class="page-links">' . esc_html__('Pages:', 'shubhu'),
                'after' => '</div>',
                ));
                ?>
            </div>
            <div class="mb-0">
                <?php
                    if( 1 == $social_share ){
                        do_action( 'shubhu_social_sharing' ,get_the_ID() );
                    }
                ?>
            </div>
        </div>
    </div>
</article><!-- #post- -->