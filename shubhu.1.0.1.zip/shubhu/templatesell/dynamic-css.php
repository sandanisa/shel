<?php
/**
 * Dynamic css
 *
 * @since Shubhu 1.0.0
 *
 * @param null
 * @return null
 *
 */
if (!function_exists('shubhu_dynamic_css')) :

    function shubhu_dynamic_css()
    {
        global $shubhu_theme_options;

        /* Color Options Options */
        $shubhu_logo_width              = absint($shubhu_theme_options['shubhu_logo_width_option']);
        $shubhu_header_overlay  = esc_attr($shubhu_theme_options['shubhu_slider_overlay_color']);
        $shubhu_header_transparent  = esc_attr($shubhu_theme_options['shubhu_slider_overlay_transparent']);
        $shubhu_header_min_height              = absint($shubhu_theme_options['shubhu_header_image_height']);
        $shubhu_slider_text_color = esc_attr($shubhu_theme_options['shubhu_slider_text_color']);
        $custom_css = '';

        //Logo Width
        if (!empty($shubhu_logo_width)) {
            $custom_css .= "
            .logo-area{ 
                max-width : ". $shubhu_logo_width."px; 
            }";
        }

        //Header Overlay
        if (!empty($shubhu_header_overlay)) {
            $custom_css .= "
            .header-bg:before { 
                background-color : ". $shubhu_header_overlay."; 
            }";
        }

        //Header Tranparent
        if (!empty($shubhu_header_transparent)) {
            $custom_css .= "
            .header-bg:before { 
                opacity : ". $shubhu_header_transparent."; 
            }";
        }
        //Slider Text Color
        if (!empty($shubhu_slider_text_color)) {
            $custom_css .= "
            .ts-slider .slick-arrow,
            .ts-slider * { 
                color : ". $shubhu_slider_text_color."; 
            }";
        }
        //Header Min Height
        if (!empty($shubhu_header_min_height)) {
            $custom_css .= "
            .header-image{ 
                min-height : ". $shubhu_header_min_height."px; 
            }";
        }

        wp_add_inline_style('shubhu-style', $custom_css);
    }
endif;
add_action('wp_enqueue_scripts', 'shubhu_dynamic_css', 99);