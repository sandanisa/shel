<?php
/**
 * Added shubhu Page.
*/

/**
 * Add a new page under Appearance
 */
function shubhu_menu() {
	add_theme_page( __( 'Shubhu Options', 'shubhu' ), __( 'Shubhu Options', 'shubhu' ), 'edit_theme_options', 'shubhu-theme', 'shubhu_page' );
}
add_action( 'admin_menu', 'shubhu_menu' );

/**
 * Enqueue styles for the help page.
 */
function shubhu_admin_scripts( $hook ) {
	if ( 'appearance_page_shubhu-theme' !== $hook ) {
		return;
	}
	wp_enqueue_style( 'shubhu-admin-style', get_template_directory_uri() . '/templatesell/about/about.css', array(), '' );
}
add_action( 'admin_enqueue_scripts', 'shubhu_admin_scripts' );

/**
 * Add the theme page
 */
function shubhu_page() {
	?>
	<div class="das-wrap">
		<div class="shubhu-panel">
			<div class="shubhu-logo">
				<img class="ts-logo" src="<?php echo esc_url( get_template_directory_uri() . '/templatesell/about/images/shubhu-logo.png' ); ?>" alt="Logo">
			</div>
			<a href="https://www.templatesell.com/item/shubhu-plus/" target="_blank" class="btn btn-success pull-right"><?php esc_html_e( 'Upgrade Pro $49', 'shubhu' ); ?></a>
			<p>
			<?php esc_html_e( 'A perfect theme for blog and magazine site. With masonry layout and multiple blog page layout, this theme is the awesome and minimal theme.', 'shubhu' ); ?></p>
			<a class="btn btn-primary" href="<?php echo esc_url (admin_url( '/customize.php?' ));
				?>"><?php esc_html_e( 'Theme Options - Click Here', 'shubhu' ); ?></a>
		</div>

		<div class="shubhu-panel">
			<div class="shubhu-panel-content">
				<div class="theme-title">
					<h3><?php esc_html_e( 'Looking for theme Documentation?', 'shubhu' ); ?></h3>
				</div>
				<a href="https://docs.templatesell.net/shubhu" target="_blank" class="btn btn-secondary"><?php esc_html_e( 'Documentation - Click Here', 'shubhu' ); ?></a>
			</div>
		</div>

		<div class="shubhu-panel">
			<div class="shubhu-panel-content">
				<div class="theme-title">
					<h3><?php esc_html_e( 'Are you in trouble while using theme?', 'shubhu' ); ?></h3>
				</div>
				<a href="https://www.templatesell.com/support/" target="_blank" class="btn btn-secondary"><?php esc_html_e( 'Support - Click Here', 'shubhu' ); ?></a>
			</div>
		</div>
		<div class="shubhu-panel">
			<div class="shubhu-panel-content">
				<div class="theme-title">
					<h3><?php esc_html_e( 'If you like the theme, please leave a review', 'shubhu' ); ?></h3>
				</div>
				<a href="https://wordpress.org/support/theme/shubhu/reviews/#new-post" target="_blank" class="btn btn-secondary"><?php esc_html_e( 'Rate this theme', 'shubhu' ); ?></a>
			</div>
		</div>
	</div>
	<?php
}
