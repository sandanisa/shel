<?php
/**
 * Shubhu Theme Customizer
 *
 * @package Shubhu
 */

if ( !function_exists('shubhu_default_theme_options_values') ) :

    function shubhu_default_theme_options_values() {

        $default_theme_options = array(

          /*Logo Options*/
          'shubhu_logo_width_option' => '300',

            /*Top Header*/
            'shubhu_enable_top_header'=> 0, 
            'shubhu_enable_top_header_social'=> 0,
            'shubhu_enable_top_header_menu'=> 0,
            'shubhu_enable_light_dark'=> 0,
            'shubhu_dark_light_logo'=> '',

            /*Header Image*/
            'shubhu_enable_header_image_overlay'=> 0,
            'shubhu_slider_overlay_color'=> '#000000',
            'shubhu_slider_overlay_transparent'=> '0.1',
            'shubhu_header_image_height'=> '100',

           /*Header Options*/
            'shubhu_enable_offcanvas'  => 0,
            'shubhu_enable_search'  => 0,

            /*Menu Options*/
            'shubhu_mobile_menu_text'  => esc_html__('Menu','shubhu'),
            'shubhu_mobile_menu_option'=> 'menu-text',

            /*Colors Options*/
            'shubhu_primary_color'              => '#d42929',
            'shubhu_slider_text_color'=> '#000000',

            /*Slider Options*/
            'shubhu_enable_slider'      => 1,
            'shubhu-select-category'    => 0,
            'shubhu_slider_type_option' => 'slider-style-two',
    
            /*Boxes Section */
            'shubhu_enable_promo'       => 1,
            'shubhu-promo-select-category'=> 0,
            
            /*Blog Page*/
            'shubhu-sidebar-blog-page' => 'no-sidebar',
            'shubhu-column-blog-page'  => 'masonry-post',
            'shubhu-blog-image-layout' => 'full-image',
            'shubhu-content-show-from' => 'no-content',
            'shubhu-excerpt-length'    => 25,
            'shubhu-pagination-options'=> 'ajax',
            'shubhu-blog-exclude-category'=> '',
            'shubhu-show-hide-share'   => 0,
            'shubhu-show-hide-category'=> 1,
            'shubhu-show-hide-date'=> 1,
            'shubhu-show-hide-author'=> 1,

            /*Single Page */
            'shubhu-single-page-featured-image' => 1,
            'shubhu-single-page-related-posts'  => 0,
            'shubhu-single-page-related-posts-title' => esc_html__('Related Posts','shubhu'),
            'shubhu-sidebar-single-page'=> 'single-right-sidebar',
            'shubhu-single-social-share' => 1,


            /*Sticky Sidebar*/
            'shubhu-enable-sticky-sidebar' => 0,

            /*Footer Section*/
            'shubhu-footer-copyright'  => esc_html__('Copyright All Rights Reserved 2022','shubhu'),

            /*Breadcrumb Options*/
            'shubhu-extra-breadcrumb' => 1,
            'shubhu-breadcrumb-selection-option'=> 'theme',

        );
return apply_filters( 'shubhu_default_theme_options_values', $default_theme_options );
}
endif;
/**
 *  Shubhu Theme Options and Settings
 *
 * @since Shubhu 1.0.0
 *
 * @param null
 * @return array shubhu_get_options_value
 *
 */
if ( !function_exists('shubhu_get_options_value') ) :
    function shubhu_get_options_value() {
        $shubhu_default_theme_options_values = shubhu_default_theme_options_values();
        $shubhu_get_options_value = get_theme_mod( 'shubhu_options');
        if( is_array( $shubhu_get_options_value )){
            return array_merge( $shubhu_default_theme_options_values, $shubhu_get_options_value );
        }
        else{
            return $shubhu_default_theme_options_values;
        }
    }
endif;

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function shubhu_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';
	
    if ( isset( $wp_customize->selective_refresh ) ) {
      $wp_customize->selective_refresh->add_partial( 'blogname', array(
         'selector'        => '.site-title a',
         'render_callback' => 'shubhu_customize_partial_blogname',
     ) );
      $wp_customize->selective_refresh->add_partial( 'blogdescription', array(
         'selector'        => '.site-description',
         'render_callback' => 'shubhu_customize_partial_blogdescription',
     ) );
  }
  $default = shubhu_default_theme_options_values();

  require get_template_directory() . '/templatesell/theme-settings/theme-settings.php';

}
add_action( 'customize_register', 'shubhu_customize_register' );

/**
 * Render the site title for the selective refresh partial.
 *
 * @return void
 */
function shubhu_customize_partial_blogname() {
	bloginfo( 'name' );
}

/**
 * Render the site tagline for the selective refresh partial.
 *
 * @return void
 */
function shubhu_customize_partial_blogdescription() {
	bloginfo( 'description' );
}
/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function shubhu_customize_preview_js() {
	wp_enqueue_script( 'shubhu-customizer', get_template_directory_uri() . '/js/customizer.js', array( 'customize-preview' ), '20200412', true );
}
add_action( 'customize_preview_init', 'shubhu_customize_preview_js' );

/*
** Customizer Styles
*/
function shubhu_panels_css() {
     wp_enqueue_style('shubhu-customizer-css', get_template_directory_uri() . '/css/customizer-style.css', array(), '4.5.0');
}
add_action( 'customize_controls_enqueue_scripts', 'shubhu_panels_css' );