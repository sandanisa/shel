<?php 
/*Logo Section*/
$wp_customize->add_setting( 'shubhu_options[shubhu_logo_width_option]', array(
    'capability'        => 'edit_theme_options',
    'transport' => 'refresh',
    'default'           => $default['shubhu_logo_width_option'],
    'sanitize_callback' => 'absint'
) );
$wp_customize->add_control( 'shubhu_options[shubhu_logo_width_option]', array(
   'label'     => __( 'Logo Width', 'shubhu' ),
   'description' => __('Adjust the logo width. Minimum is 100px and maximum is 600px.', 'shubhu'),
   'section'   => 'title_tagline',
   'settings'  => 'shubhu_options[shubhu_logo_width_option]',
   'type'      => 'range',
   'priority'  => 15,
   'input_attrs' => array(
          'min' => 100,
          'max' => 600,
        ),
) );


 /*Dark Mode Logo*/
 $wp_customize->add_setting( 'shubhu_options[shubhu_dark_light_logo]', array(
  'capability'        => 'edit_theme_options',
  'transport' => 'refresh',
  'default'           => $default['shubhu_dark_light_logo'],
  'sanitize_callback' => 'shubhu_sanitize_image'
) );

$wp_customize->add_control( 
  new WP_Customize_Image_Control(
  $wp_customize,
  'shubhu_options[shubhu_dark_light_logo]', array(
  'label'     => __( 'Dark Mode Logo', 'shubhu' ),
  'description' => __('You can upload a different logo for the dark mode.', 'shubhu'),
  'section'   => 'title_tagline',
  'settings'  => 'shubhu_options[shubhu_dark_light_logo]',
  'type'      => 'image',
  'priority'  => 6,
    )
) );