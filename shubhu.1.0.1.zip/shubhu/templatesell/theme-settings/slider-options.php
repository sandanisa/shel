<?php
/*Slider Options*/
$GLOBALS['shubhu_theme_options'] = shubhu_get_options_value();

$wp_customize->add_section( 'shubhu_slider_section', array(
   'priority'       => 20,
   'capability'     => 'edit_theme_options',
   'theme_supports' => '',
   'title'          => __( 'Slider Settings', 'shubhu' ),
   'panel' 		 => 'shubhu_panel',
) );

/*callback functions slider*/
if ( !function_exists('shubhu_slider_active_callback') ) :
  function shubhu_slider_active_callback(){
      global $shubhu_theme_options;
      $enable_slider = absint($shubhu_theme_options['shubhu_enable_slider']);
      if( 1 == $enable_slider ){
          return true;
      }
      else{
          return false;
      }
  }
endif;


/*Slider Enable Option*/
$wp_customize->add_setting( 'shubhu_options[shubhu_enable_slider]', array(
   'capability'        => 'edit_theme_options',
   'transport' => 'refresh',
   'default'           => $default['shubhu_enable_slider'],
   'sanitize_callback' => 'shubhu_sanitize_checkbox'
) );

$wp_customize->add_control(
    'shubhu_options[shubhu_enable_slider]', 
    array(
       'label'     => __( 'Enable Slider', 'shubhu' ),
       'description' => __('You can select the category for the slider below. More Options are available on premium version.', 'shubhu'),
       'section'   => 'shubhu_slider_section',
       'settings'  => 'shubhu_options[shubhu_enable_slider]',
        'type'      => 'checkbox',
       'priority'  => 15,
   )
 );        
/*Slider Type*/
$wp_customize->add_setting( 'shubhu_options[shubhu_slider_type_option]', array(
  'capability'        => 'edit_theme_options',
  'transport' => 'refresh',
  'default'           => $default['shubhu_slider_type_option'],
  'sanitize_callback' => 'shubhu_sanitize_select'
) );
$wp_customize->add_control( 'shubhu_options[shubhu_slider_type_option]', array(
  'choices' => array(
    'slider-style-one' => __('Slider Style One', 'shubhu'),
    'slider-style-two' => __('Slider Style Two', 'shubhu'),
),
 'label'     => __( 'Slider Type', 'shubhu' ),
 'description' => __('Chose your slider style.', 'shubhu'),
 'section'   => 'shubhu_slider_section',
 'settings'  => 'shubhu_options[shubhu_slider_type_option]',
 'type'      => 'select',
 'priority'  => 15,
 'active_callback'=> 'shubhu_slider_active_callback',
) );
  

/*Slider Category Selection*/
$wp_customize->add_setting( 'shubhu_options[shubhu-select-category]', array(
    'capability'        => 'edit_theme_options',
    'transport' => 'refresh',
    'default'           => $default['shubhu-select-category'],
    'sanitize_callback' => 'absint'

) );

$wp_customize->add_control(
    new Shubhu_Customize_Category_Dropdown_Control(
        $wp_customize,
        'shubhu_options[shubhu-select-category]',
        array(
            'label'     => __( 'Select Category For Slider', 'shubhu' ),
            'description' => __('Choose one category to show the slider. More settings are in pro version.', 'shubhu'),
            'section'   => 'shubhu_slider_section',
            'settings'  => 'shubhu_options[shubhu-select-category]',
            'type'      => 'category_dropdown',
            'priority'  => 15,
            'active_callback'=> 'shubhu_slider_active_callback',
        )
    )
);


/*callback functions slider*/
if ( !function_exists('shubhu_slider_color_active_callback') ) :
    function shubhu_slider_color_active_callback(){
        global $shubhu_theme_options;
        $enable_slider = absint($shubhu_theme_options['shubhu_enable_slider']);
        $slider_type = esc_attr($shubhu_theme_options['shubhu_slider_type_option']);
        if( 1 == $enable_slider && 'slider-style-one' == $slider_type ){
            return true;
        }
        else{
            return false;
        }
    }
  endif;

/* Slider color options */
$wp_customize->add_setting( 'shubhu_options[shubhu_slider_text_color]',
    array(
        'default'           => $default['shubhu_slider_text_color'],
        'sanitize_callback' => 'sanitize_hex_color',
    )
);
$wp_customize->add_control(
    new WP_Customize_Color_Control(                 
        $wp_customize,
        'shubhu_options[shubhu_slider_text_color]',
        array(
            'label'       => esc_html__( 'Slider Text Color', 'shubhu' ),
            'description' => esc_html__( 'Change the slider text color from here.', 'shubhu' ),
            'section'     => 'shubhu_slider_section', 
            'priority'  => 20, 
            'active_callback'=> 'shubhu_slider_color_active_callback',
        )
    )
);
