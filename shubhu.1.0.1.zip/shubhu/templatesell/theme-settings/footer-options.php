<?php
/*Footer Options*/
$wp_customize->add_section('shubhu_footer_section', array(
    'priority' => 20,
    'capability' => 'edit_theme_options',
    'theme_supports' => '',
    'title' => __('Footer Settings', 'shubhu'),
    'panel' => 'shubhu_panel',
));


/*Copyright Setting*/
$wp_customize->add_setting('shubhu_options[shubhu-footer-copyright]', array(
    'capability' => 'edit_theme_options',
    'transport' => 'refresh',
    'default' => $default['shubhu-footer-copyright'],
    'sanitize_callback' => 'sanitize_text_field'
));

$wp_customize->add_control('shubhu_options[shubhu-footer-copyright]', array(
    'label' => __('Copyright Text', 'shubhu'),
    'description' => __('Enter your own copyright text.', 'shubhu'),
    'section' => 'shubhu_footer_section',
    'settings' => 'shubhu_options[shubhu-footer-copyright]',
    'type' => 'text',
    'priority' => 15,
));
