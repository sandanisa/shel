<?php
$GLOBALS['shubhu_theme_options'] = shubhu_get_options_value();

/*Top Header Options*/
$wp_customize->add_section( 'shubhu_top_header_section', array(
   'priority'       => 20,
   'capability'     => 'edit_theme_options',
   'theme_supports' => '',
   'title'          => __( 'Quick Section', 'shubhu' ),
   'panel' 		 => 'shubhu_panel',
) );

/*callback functions header section*/
if ( !function_exists('shubhu_header_active_callback') ) :
  function shubhu_header_active_callback(){
      global $shubhu_theme_options;
      $enable_header = absint($shubhu_theme_options['shubhu_enable_top_header']);
      if( 1 == $enable_header ){
          return true;
      }
      else{
          return false;
      }
  }
endif;

/*Enable Top Header Section*/
$wp_customize->add_setting( 'shubhu_options[shubhu_enable_top_header]', array(
   'capability'        => 'edit_theme_options',
   'transport' => 'refresh',
   'default'           => $default['shubhu_enable_top_header'],
   'sanitize_callback' => 'shubhu_sanitize_checkbox'
) );

$wp_customize->add_control( 'shubhu_options[shubhu_enable_top_header]', array(
   'label'     => __( 'Enable Quick Section', 'shubhu' ),
   'description' => __('Checked to show the top header section like search and social icons', 'shubhu'),
   'section'   => 'shubhu_top_header_section',
   'settings'  => 'shubhu_options[shubhu_enable_top_header]',
   'type'      => 'checkbox',
   'priority'  => 5,
) );

/*Enable Social Icons In Header*/
$wp_customize->add_setting( 'shubhu_options[shubhu_enable_top_header_social]', array(
   'capability'        => 'edit_theme_options',
   'transport' => 'refresh',
   'default'           => $default['shubhu_enable_top_header_social'],
   'sanitize_callback' => 'shubhu_sanitize_checkbox'
) );

$wp_customize->add_control( 'shubhu_options[shubhu_enable_top_header_social]', array(
   'label'     => __( 'Enable Social Icons', 'shubhu' ),
   'description' => __('You can show the social icons here. Manage social icons from Appearance > Menus. Social Menu will display here.', 'shubhu'),
   'section'   => 'shubhu_top_header_section',
   'settings'  => 'shubhu_options[shubhu_enable_top_header_social]',
   'type'      => 'checkbox',
   'priority'  => 5,
   'active_callback'=>'shubhu_header_active_callback'
) );


/*Header Search Enable Option*/
$wp_customize->add_setting( 'shubhu_options[shubhu_enable_search]', array(
    'capability'        => 'edit_theme_options',
    'transport' => 'refresh',
    'default'           => $default['shubhu_enable_search'],
    'sanitize_callback' => 'shubhu_sanitize_checkbox'
) );

$wp_customize->add_control( 'shubhu_options[shubhu_enable_search]', array(
    'label'     => __( 'Enable Search', 'shubhu' ),
    'description' => __('It will help to display the search in Menu.', 'shubhu'),
    'section'   => 'shubhu_top_header_section',
    'settings'  => 'shubhu_options[shubhu_enable_search]',
    'type'      => 'checkbox',
    'priority'  => 5,
    'active_callback'=>'shubhu_header_active_callback'

) );

/* Header Image Additional Options */
/*Enable Overlay on the Header Image Part*/
$wp_customize->add_setting( 'shubhu_options[shubhu_enable_header_image_overlay]', array(
   'capability'        => 'edit_theme_options',
   'transport' => 'refresh',
   'default'           => $default['shubhu_enable_header_image_overlay'],
   'sanitize_callback' => 'shubhu_sanitize_checkbox'
) );

$wp_customize->add_control(
    'shubhu_options[shubhu_enable_header_image_overlay]', 
    array(
       'label'     => __( 'Enable Header Image Overlay Color Height', 'shubhu' ),
       'description' => __('This option will add colors over the header image.', 'shubhu'),
       'section'   => 'header_image',
       'settings'  => 'shubhu_options[shubhu_enable_header_image_overlay]',
        'type'      => 'checkbox',
       'priority'  => 15,
   )
 );

/*callback functions slider getting from post*/
if ( !function_exists('shubhu_header_overlay_color_active_callback') ) :
  function shubhu_header_overlay_color_active_callback(){
      global $shubhu_theme_options;
      $slider_overlay = absint($shubhu_theme_options['shubhu_enable_header_image_overlay']);
      if( $slider_overlay == 1 ){
          return true;
      }
      else{
          return false;
      }
  }
endif;  

/*Header Image Height*/
$wp_customize->add_setting( 'shubhu_options[shubhu_header_image_height]', array(
    'capability'        => 'edit_theme_options',
    'transport' => 'refresh',
    'default'           => $default['shubhu_header_image_height'],
    'sanitize_callback' => 'absint'
) );
$wp_customize->add_control( 'shubhu_options[shubhu_header_image_height]', array(
   'label'     => __( 'Header Image Min Height', 'shubhu' ),
   'description' => __('Adjust the header image min height height. Minimum is 50px and maximum is 500px.', 'shubhu'),
   'section'   => 'header_image',
   'settings'  => 'shubhu_options[shubhu_header_image_height]',
   'type'      => 'range',
   'priority'  => 15,
   'input_attrs' => array(
          'min' => 50,
          'max' => 500,
        ),
    'active_callback'=> 'shubhu_header_overlay_color_active_callback',
) ); 

/* Select the color for the Overlay */
$wp_customize->add_setting( 'shubhu_options[shubhu_slider_overlay_color]',
    array(
        'default'           => $default['shubhu_slider_overlay_color'],
        'sanitize_callback' => 'sanitize_hex_color',
    )
);
$wp_customize->add_control(
    new WP_Customize_Color_Control(                 
        $wp_customize,
        'shubhu_options[shubhu_slider_overlay_color]',
        array(
            'label'       => esc_html__( 'Header Image Overlay Color', 'shubhu' ),
            'description' => esc_html__( 'It will add the color overlay of the Header image. To make it transparent, use the below option.', 'shubhu' ),
            'section'     => 'header_image', 
            'priority'  => 15, 
            'active_callback'=> 'shubhu_header_overlay_color_active_callback',
        )
    )
);

/*Overlay Range for transparent*/
$wp_customize->add_setting( 'shubhu_options[shubhu_slider_overlay_transparent]', array(
    'capability'        => 'edit_theme_options',
    'transport' => 'refresh',
    'default'           => $default['shubhu_slider_overlay_transparent'],
    'sanitize_callback' => 'shubhu_sanitize_number'
) );
$wp_customize->add_control( 'shubhu_options[shubhu_slider_overlay_transparent]', array(
   'label'     => __( 'Header Image Overlay Color Transparent', 'shubhu' ),
   'description' => __('You can make the overlay transparent using this option. Add range from 0.1 to 1.', 'shubhu'),
   'section'   => 'header_image',
   'settings'  => 'shubhu_options[shubhu_slider_overlay_transparent]',
   'type'      => 'number',
   'priority'  => 15,
   'input_attrs' => array(
        'min' => '0.1',
        'max' => '1',
        'step' => '0.1',
    ),
   'active_callback' => 'shubhu_header_overlay_color_active_callback',
) );



