<?php
/*Blog Page Options*/
$wp_customize->add_section('shubhu_blog_page_section', array(
    'priority' => 20,
    'capability' => 'edit_theme_options',
    'theme_supports' => '',
    'title' => __('Blog Settings', 'shubhu'),
    'panel' => 'shubhu_panel',
));
/*Blog Page Sidebar Layout*/

$wp_customize->add_setting('shubhu_options[shubhu-sidebar-blog-page]', array(
    'capability' => 'edit_theme_options',
    'transport' => 'refresh',
    'default' => $default['shubhu-sidebar-blog-page'],
    'sanitize_callback' => 'shubhu_sanitize_select'
));

$wp_customize->add_control( new Shubhu_Radio_Image_Control(
        $wp_customize,
    'shubhu_options[shubhu-sidebar-blog-page]', array(
    'choices' => shubhu_blog_sidebar_position_array(),
    'label' => __('Blog and Archive Sidebar', 'shubhu'),
    'description' => __('This sidebar will work blog and archive pages.', 'shubhu'),
    'section' => 'shubhu_blog_page_section',
    'settings' => 'shubhu_options[shubhu-sidebar-blog-page]',
    'type' => 'select',
    'priority' => 15,
)));


/*Blog Page column number*/
$wp_customize->add_setting('shubhu_options[shubhu-column-blog-page]', array(
    'capability' => 'edit_theme_options',
    'transport' => 'refresh',
    'default' => $default['shubhu-column-blog-page'],
    'sanitize_callback' => 'shubhu_sanitize_select'
));

$wp_customize->add_control('shubhu_options[shubhu-column-blog-page]', array(
    'choices' => array(
        'one-column' => __('Single Layout', 'shubhu'),
        'masonry-post' => __('Masonry Layout', 'shubhu'),
    
    ),
    'label' => __('Blog Layout Options', 'shubhu'),
    'description' => __('Change your blog or archive page layout.', 'shubhu'),
    'section' => 'shubhu_blog_page_section',
    'settings' => 'shubhu_options[shubhu-column-blog-page]',
    'type' => 'select',
    'priority' => 15,
));


/*Image Layout Options For Blog Page*/
$wp_customize->add_setting('shubhu_options[shubhu-blog-image-layout]', array(
    'capability' => 'edit_theme_options',
    'transport' => 'refresh',
    'default' => $default['shubhu-blog-image-layout'],
    'sanitize_callback' => 'shubhu_sanitize_select'
));

$wp_customize->add_control('shubhu_options[shubhu-blog-image-layout]', array(
    'choices' => array(
        'full-image' => __('Full Layout', 'shubhu'),
        'left-image' => __('Grid Layout', 'shubhu'),
    
    ),
    'label' => __('Blog Page Layout', 'shubhu'),
    'description' => __('This will work only on Full layout Option', 'shubhu'),
    'section' => 'shubhu_blog_page_section',
    'settings' => 'shubhu_options[shubhu-blog-image-layout]',
    'type' => 'select',
    'priority' => 15,
));

/*Blog Page Show content from*/
$wp_customize->add_setting('shubhu_options[shubhu-content-show-from]', array(
    'capability' => 'edit_theme_options',
    'transport' => 'refresh',
    'default' => $default['shubhu-content-show-from'],
    'sanitize_callback' => 'shubhu_sanitize_select'
));

$wp_customize->add_control('shubhu_options[shubhu-content-show-from]', array(
    'choices' => array(
        'excerpt' => __('Show from Excerpt', 'shubhu'),
        'content' => __('Show from Content', 'shubhu'),
        'no-content' => __('No Content', 'shubhu'),
    ),
    'label' => __('Select Content Display From', 'shubhu'),
    'description' => __('You can enable excerpt from Screen Options inside post section of dashboard', 'shubhu'),
    'section' => 'shubhu_blog_page_section',
    'settings' => 'shubhu_options[shubhu-content-show-from]',
    'type' => 'select',
    'priority' => 15,
));


/*Blog Page excerpt length*/
$wp_customize->add_setting('shubhu_options[shubhu-excerpt-length]', array(
    'capability' => 'edit_theme_options',
    'transport' => 'refresh',
    'default' => $default['shubhu-excerpt-length'],
    'sanitize_callback' => 'absint'

));

$wp_customize->add_control('shubhu_options[shubhu-excerpt-length]', array(
    'label' => __('Excerpt Length', 'shubhu'),
    'description' => __('Enter the number per Words to show the content in blog page.', 'shubhu'),
    'section' => 'shubhu_blog_page_section',
    'settings' => 'shubhu_options[shubhu-excerpt-length]',
    'type' => 'number',
    'priority' => 15,
));

/*Exclude Category in Blog Page*/
$wp_customize->add_setting('shubhu_options[shubhu-blog-exclude-category]', array(
    'capability' => 'edit_theme_options',
    'transport' => 'refresh',
    'default' => $default['shubhu-blog-exclude-category'],
    'sanitize_callback' => 'sanitize_text_field'
));

$wp_customize->add_control('shubhu_options[shubhu-blog-exclude-category]', array(
    'label' => __('Exclude categories in Blog Listing', 'shubhu'),
    'description' => __('Enter categories ids with comma separated eg: 2,7,14,47.', 'shubhu'),
    'section' => 'shubhu_blog_page_section',
    'settings' => 'shubhu_options[shubhu-blog-exclude-category]',
    'type' => 'text',
    'priority' => 15,
));

/*Blog Page Pagination Options*/
$wp_customize->add_setting('shubhu_options[shubhu-pagination-options]', array(
    'capability' => 'edit_theme_options',
    'transport' => 'refresh',
    'default' => $default['shubhu-pagination-options'],
    'sanitize_callback' => 'shubhu_sanitize_select'

));

$wp_customize->add_control('shubhu_options[shubhu-pagination-options]', array(
    'choices' => array(
        'numeric' => __('Numeric Pagination', 'shubhu'),
        'ajax' => __('Ajax Pagination', 'shubhu'),
    ),
    'label' => __('Pagination Types', 'shubhu'),
    'description' => __('Choose Required Pagination Type', 'shubhu'),
    'section' => 'shubhu_blog_page_section',
    'settings' => 'shubhu_options[shubhu-pagination-options]',
    'type' => 'select',
    'priority' => 15,
));




/*Social Share in blog page*/
$wp_customize->add_setting('shubhu_options[shubhu-show-hide-share]', array(
    'capability' => 'edit_theme_options',
    'transport' => 'refresh',
    'default' => $default['shubhu-show-hide-share'],
    'sanitize_callback' => 'shubhu_sanitize_checkbox'
));

$wp_customize->add_control('shubhu_options[shubhu-show-hide-share]', array(
    'label' => __('Show Social Share', 'shubhu'),
    'description' => __('Options to Enable Social Share in blog and archive page.', 'shubhu'),
    'section' => 'shubhu_blog_page_section',
    'settings' => 'shubhu_options[shubhu-show-hide-share]',
    'type' => 'checkbox',
    'priority' => 15,
));

/*Category Show hide*/
$wp_customize->add_setting('shubhu_options[shubhu-show-hide-category]', array(
    'capability' => 'edit_theme_options',
    'transport' => 'refresh',
    'default' => $default['shubhu-show-hide-category'],
    'sanitize_callback' => 'shubhu_sanitize_checkbox'
));

$wp_customize->add_control('shubhu_options[shubhu-show-hide-category]', array(
    'label' => __('Show Category', 'shubhu'),
    'description' => __('Option to hide the category on the blog page.', 'shubhu'),
    'section' => 'shubhu_blog_page_section',
    'settings' => 'shubhu_options[shubhu-show-hide-category]',
    'type' => 'checkbox',
    'priority' => 15,
));
/*Date Show hide*/
$wp_customize->add_setting('shubhu_options[shubhu-show-hide-date]', array(
    'capability' => 'edit_theme_options',
    'transport' => 'refresh',
    'default' => $default['shubhu-show-hide-date'],
    'sanitize_callback' => 'shubhu_sanitize_checkbox'
));

$wp_customize->add_control('shubhu_options[shubhu-show-hide-date]', array(
    'label' => __('Show Date', 'shubhu'),
    'description' => __('Option to hide the date on the blog page.', 'shubhu'),
    'section' => 'shubhu_blog_page_section',
    'settings' => 'shubhu_options[shubhu-show-hide-date]',
    'type' => 'checkbox',
    'priority' => 15,
));
/*Author Show hide*/
$wp_customize->add_setting('shubhu_options[shubhu-show-hide-author]', array(
    'capability' => 'edit_theme_options',
    'transport' => 'refresh',
    'default' => $default['shubhu-show-hide-author'],
    'sanitize_callback' => 'shubhu_sanitize_checkbox'
));

$wp_customize->add_control('shubhu_options[shubhu-show-hide-author]', array(
    'label' => __('Show Author', 'shubhu'),
    'description' => __('Option to hide the author on the blog page.', 'shubhu'),
    'section' => 'shubhu_blog_page_section',
    'settings' => 'shubhu_options[shubhu-show-hide-author]',
    'type' => 'checkbox',
    'priority' => 15,
));
/*Category Show hide*/
$wp_customize->add_setting('shubhu_options[shubhu-show-hide-category]', array(
    'capability' => 'edit_theme_options',
    'transport' => 'refresh',
    'default' => $default['shubhu-show-hide-category'],
    'sanitize_callback' => 'shubhu_sanitize_checkbox'
));

$wp_customize->add_control('shubhu_options[shubhu-show-hide-category]', array(
    'label' => __('Show Category', 'shubhu'),
    'description' => __('Option to hide the category on the blog page.', 'shubhu'),
    'section' => 'shubhu_blog_page_section',
    'settings' => 'shubhu_options[shubhu-show-hide-category]',
    'type' => 'checkbox',
    'priority' => 15,
));

