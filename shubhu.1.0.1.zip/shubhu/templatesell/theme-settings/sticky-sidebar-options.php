<?php 
/*Sticky Sidebar*/
$wp_customize->add_section( 'shubhu_sticky_sidebar', array(
   'priority'       => 20,
   'capability'     => 'edit_theme_options',
   'theme_supports' => '',
   'title'          => __( 'Sticky Sidebar Settings', 'shubhu' ),
   'panel' 		 => 'shubhu_panel',
) );

/*Sticky Sidebar Setting*/
$wp_customize->add_setting( 'shubhu_options[shubhu-enable-sticky-sidebar]', array(
    'capability'        => 'edit_theme_options',
    'transport' => 'refresh',
    'default'           => $default['shubhu-enable-sticky-sidebar'],
    'sanitize_callback' => 'shubhu_sanitize_checkbox'
) );

$wp_customize->add_control( 'shubhu_options[shubhu-enable-sticky-sidebar]', array(
    'label'     => __( 'Enable Sticky Sidebar', 'shubhu' ),
    'description' => __('Enable and Disable sticky sidebar from this section.', 'shubhu'),
    'section'   => 'shubhu_sticky_sidebar',
    'settings'  => 'shubhu_options[shubhu-enable-sticky-sidebar]',
    'type'      => 'checkbox',
    'priority'  => 15,
) );