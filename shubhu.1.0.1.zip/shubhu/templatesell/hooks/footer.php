<?php
/**
 * Goto Top functions
 *
 * @since Shubhu 1.0.0
 *
 */

if (!function_exists('shubhu_go_to_top')) :
    function shubhu_go_to_top()
    {
    ?>
    <div id="scrollUp">
        <i class="ti-arrow-up"></i>
    </div>
<?php
    } endif;
add_action('shubhu_go_to_top_hook', 'shubhu_go_to_top', 10, 1);