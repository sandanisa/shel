<?php
/**
 * Post Navigation Function
 *
 * @since Shubhu 1.0.0
 *
 * @param null
 * @return void
 *
 */
if (!function_exists('shubhu_posts_navigation')) :
    function shubhu_posts_navigation()
    {
        global $shubhu_theme_options;
        $shubhu_pagination_option = $shubhu_theme_options['shubhu-pagination-options'];
        if ('numeric' == $shubhu_pagination_option) {
            echo "<div class='pagination-area'><div class='navigation pagination justify-content-center'><div class='nav-links text-center'>";
            global $wp_query;
            $big = 999999999; // need an unlikely integer
            echo paginate_links(array(
                'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
                'format' => '?paged=%#%',
                'current' => max(1, get_query_var('paged')),
                'total' => $wp_query->max_num_pages,
                'prev_text' => __('<i class="fa fa-angle-left"></i>', 'shubhu'),
                'next_text' => __('<i class="fa fa-angle-right"></i>', 'shubhu'),
            ));
            echo "<div>";
        } elseif ('ajax' == $shubhu_pagination_option) {
            $page_number = get_query_var('paged');
            if ($page_number == 0) {
                $output_page = 2;
            } else {
                $output_page = $page_number + 1;
            }
            if(paginate_links()) {
            echo "<div class='ajax-pagination text-center'>
            <div class='show-more btn btn-dark btn-lg' data-number='$output_page'>
            <i class='fa fa-refresh mr-2'></i>" . __('View More', 'shubhu') . "</div><div id='free-temp-post'></div></div>";
            }
        } else {
            return false;
        }
    }
endif;
add_action('shubhu_action_navigation', 'shubhu_posts_navigation', 10);