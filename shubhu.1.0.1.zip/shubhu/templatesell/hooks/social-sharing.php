<?php
/**
 * Social Sharing Hook *
 * @since 1.0.0
 *
 * @param int $post_id
 * @return void
 *
 */
if (!function_exists('shubhu_social_sharing')) :
    function shubhu_social_sharing($post_id)
    {
        $shubhu_url = get_the_permalink($post_id);
        $shubhu_title = get_the_title($post_id);
        $shubhu_image = get_the_post_thumbnail_url($post_id);
        
        //sharing url
        $shubhu_twitter_sharing_url = esc_url('http://twitter.com/share?text=' . $shubhu_title . '&url=' . $shubhu_url);
        $shubhu_facebook_sharing_url = esc_url('https://www.facebook.com/sharer/sharer.php?u=' . $shubhu_url);
        $shubhu_pinterest_sharing_url = esc_url('http://pinterest.com/pin/create/button/?url=' . $shubhu_url . '&media=' . $shubhu_image . '&description=' . $shubhu_title);
        $shubhu_linkedin_sharing_url = esc_url('http://www.linkedin.com/shareArticle?mini=true&title=' . $shubhu_title . '&url=' . $shubhu_url);
        
        ?>
        <div class="meta-share">
            <ul class="list-inline">
                <li class="list-inline-item"><a target="_blank" href="<?php echo $shubhu_facebook_sharing_url; ?>"><i class="fa fa-facebook"></i></a></li>
                <li class="list-inline-item"><a target="_blank" href="<?php echo $shubhu_twitter_sharing_url; ?>"><i
                            class="fa fa-twitter"></i></a></li>
                <li class="list-inline-item"><a target="_blank" href="<?php echo $shubhu_pinterest_sharing_url; ?>"><i
                            class="fa fa-pinterest"></i></a></li>
                <li class="list-inline-item"><a target="_blank" href="<?php echo $shubhu_linkedin_sharing_url; ?>"><i class="fa fa-linkedin"></i></a></li>
            </ul>
        </div>
        <?php
    }
endif;
add_action('shubhu_social_sharing', 'shubhu_social_sharing', 10);