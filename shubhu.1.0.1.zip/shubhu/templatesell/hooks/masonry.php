<?php
/**
 * Masonry Start Class and Id functions
 *
 * @since Shubhu 1.0.0
 *
 */
if (!function_exists('shubhu_masonry_start')) :
    function shubhu_masonry_start()
    {
        global $shubhu_theme_options;
        $is_masonry =  esc_attr($shubhu_theme_options['shubhu-column-blog-page']);
            if($is_masonry == 'masonry-post'){
            ?>
                <div class="masonry-start"><div id="masonry-loop">
            
            <?php
        }
    }
endif;
add_action('shubhu_masonry_start_hook', 'shubhu_masonry_start', 10, 1);

/**
 * Masonry end Div
 *
 * @since Shubhu 1.0.0
 *
 */
if (!function_exists('shubhu_masonry_end')) :
    function shubhu_masonry_end()
    { 
        global $shubhu_theme_options;
            $is_masonry =  esc_attr($shubhu_theme_options['shubhu-column-blog-page']);
                if($is_masonry == 'masonry-post'){
            ?>
                </div>
                </div>
            
            <?php
        }
    }
endif;
add_action('shubhu_masonry_end_hook', 'shubhu_masonry_end', 10, 1);