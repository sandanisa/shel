<?php

if ( ! function_exists( 'shubhu_load_widgets' ) ) :

    /**
     * Load widgets.
     *
     * @since 1.0.0
     */
    function shubhu_load_widgets() {

        // Highlight Post.
        register_widget( 'Shubhu_Featured_Post' );

        // Author Widget.
        register_widget( 'Shubhu_Author_Widget' );
    }
endif;
add_action( 'widgets_init', 'shubhu_load_widgets' );


